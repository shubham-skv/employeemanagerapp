package tech.getarrays.employeemanager.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import tech.getarrays.employeemanager.model.Doctor;

public interface DoctorRepo extends JpaRepository<Doctor,Long> {

void deleteDoctorById(long id);

}
