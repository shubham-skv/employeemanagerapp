package tech.getarrays.employeemanager.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tech.getarrays.employeemanager.exception.UserNotFoundException;
import tech.getarrays.employeemanager.model.Doctor;
import tech.getarrays.employeemanager.repo.DoctorRepo;

import java.util.List;
import java.util.Optional;

@Service
public class DoctorService {
    private final DoctorRepo doctorRepo;
    @Autowired
    public DoctorService(DoctorRepo doctorRepo){
        this.doctorRepo=doctorRepo;
    }

    public Doctor addDoctor(Doctor doctor){
        return doctorRepo.save(doctor);
    }

    public List<Doctor> findAllDoctors(){
        return doctorRepo.findAll();
    }

    public Doctor updateDoctor(Doctor doctor){
        return doctorRepo.save(doctor);
    }

    public Doctor findDoctorById(Long id){
        return doctorRepo.findById(id).orElseThrow(()->new UserNotFoundException("Doctor by id "+id+" not found"));
    }

    public void deleteDoctor(Long id){
         doctorRepo.deleteById(id);
    }
    public void deleteDoc(Doctor doctor){
        doctorRepo.delete(doctor);
    }



}
